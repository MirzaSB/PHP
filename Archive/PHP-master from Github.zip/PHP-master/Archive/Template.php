<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=MacRoman">
<title>Insert title here</title>
</head>
<body>
	<p>Insert paragraph here</p>
    <?php
    	
	?>
    </body>
</html>
