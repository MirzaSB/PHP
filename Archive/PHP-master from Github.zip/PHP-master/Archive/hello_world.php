<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=MacRoman">
<title>Insert title here</title>
</head>
<body>
	<p>This page uses frames. The current browser you are using does not support frames.</p>
    <?php
    	$myHello = "Hello World";
    	echo $myHello;
	?>
    </body>
</html>
